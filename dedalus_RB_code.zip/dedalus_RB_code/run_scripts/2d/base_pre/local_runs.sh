mpirun -n 2 python3 rayleigh_benard.py --aspect=2 --nx=64 --nz=32 --root_dir=runs/base_pre --run_time_therm=1 --mixed_flux_T --no_slip --Rayleigh=2.79e3
mpirun -n 2 python3 rayleigh_benard.py --aspect=2 --nx=64 --nz=32 --root_dir=runs/base_pre --run_time_therm=1 --mixed_flux_T --no_slip --Rayleigh=6.01e3
mpirun -n 2 python3 rayleigh_benard.py --aspect=2 --nx=64 --nz=32 --root_dir=runs/base_pre --run_time_therm=1 --mixed_flux_T --no_slip --Rayleigh=1.30e4
mpirun -n 2 python3 rayleigh_benard.py --aspect=2 --nx=64 --nz=32 --root_dir=runs/base_pre --run_time_therm=1 --mixed_flux_T --no_slip --Rayleigh=2.79e4
mpirun -n 2 python3 rayleigh_benard.py --aspect=2 --nx=64 --nz=32 --root_dir=runs/base_pre --run_time_therm=1 --mixed_flux_T --no_slip --Rayleigh=6.01e4
